#ifndef __MERGE__
#define __MERGE__

void myMergeSort(visitas *valores, int esq, int dir);


#endif
